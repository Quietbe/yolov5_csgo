import sys
sys.path.append('E:\Pycharm\Python_Projects\yolov5')
import math
import time
import torch
from grabscreen import grab_screen_mss
import numpy as np
from utils.general import non_max_suppression, scale_boxes, xyxy2xywh
from utils.augmentations import letterbox
import pynput
from pynput.mouse import Listener
from mouse_controler import lock
from models.common import DetectMultiBackend
from threading import Thread
from SendInput import mouse_xy
from utils.torch_utils import smart_inference_mode

# from PositionalPID import PID  #位置式
from IncrementalPID import PID   #增量式
# conf_thres = 0.6  #执行度
# iou_thres = 0.05  #交并比
# agnostic_nms = False
# max_det = 1000
# #截图相关参数-------------
# x, y = 2560, 1440  # 截图范围size
# x_c, y_c = 640,640  #截图大小
# x1, y1, x2, y2 = int(x/2-x_c/2), int(y/2-x_c/2), int(x/2+x_c/2), int(y/2+x_c/2)
# re_x, re_y = 640, 640 # 显示size
# #------------------------------
# #PID係數可調整
# #PID(P, I, D)
# #P: 加快系統反映。輸出值較快，但越大越不穩定
# #I: 積分。用於穩定誤差
# #D: 微分。提高系統的動態性能
# #以下為個人使用參數可供參考
# pidx = PID(0.5, 0.09, 0.1, setpoint=0, sample_time=0.0001,)
# # pidy = PID(1, 16, 0.001, setpoint=0, sample_time=0,)
# # pidx.output_limits = (-x_c, x_c)
# # pidy.output_limits = (-y_c, y_c)
# #----------------------------------------------
#
# ## 加载模型
# weights=r'E:\Pycharm\Python_Projects\yolov5\aim-csgo\model\best_csgo.engine'
# # weights=r'E:\Pycharm\Python_Projects\yolov5\aim-csgo\model\csgo_28600p_20ep_5n_5.0_4lab.wts'
# imgsz = 640
# # device = 'cuda' if torch.cuda.is_available() else 'cpu'
# # model = load_model(weights=weights)
# device = torch.device('cuda')
# print("device ", device)
# model = DetectMultiBackend(weights, device=device, dnn=False, data=False, fp16=True)
# #-----------------
# stride, names, pt = model.stride, model.names, model.pt

mouse = pynput.mouse.Controller()
lock_mode = False  #程序开启
mouse_move = False

conf_thres = 0.45  # 置信度
iou_thres = 0.05  # 交并比
# 截图相关参数-------------
x, y = 2560, 1440  # 截图范围size
x_c, y_c = 640, 640  # 截图大小
k = x_c/2            #计算移动距离时用 减去截图大小的一半
move_P = 1
x1, y1, x2, y2 = int(x / 2 - x_c / 2), int(y / 2 - x_c / 2), int(x / 2 + x_c / 2), int(y / 2 + x_c / 2)


def open_click(x, y, button, pressed):
    global lock_mode
    if pressed and button == pynput.mouse.Button.middle:
        lock_mode = not lock_mode
        print('lock mode', 'on' if lock_mode else 'off')
    # elif not pressed and button == pynput.mouse.Button.middle:
    #     lock_mode = False
    #     print("关闭")


def open_listener():
    with Listener(on_click=open_click) as listener:
        listener.join()


def on_move(x, y):
    global mouse_move
    mouse_move = True
    print('正在移动', x, y)


def move_Listener():
    with Listener(on_move=on_move) as listener:
        listener.join()
#P=0.5, I=0.09, D=0.1  #P=0.81, I=0.22, D=0.19  #P=0.2,I=0.03,D=0.28 #P=0.6,I=0.03, D=0.1
#kp = 0.9; ki = 0.088; kd = 0.114
#P = 0.5 I = 0.113 D = 0.102
kp = 0.5; ki = 0.09; kd = 0.1
add = True
pidx = PID(P=kp, I=ki, D=kd, max_m=x_c/2)
pidy = PID(P=kp, I=ki, D=kd, max_m=x_c/2)

#PID调参函数  P   I   K
def Key_press(key):
    global kp,ki,kd,add,pidx,pidy
    try:
        if key.char == "=":
            print("当前为 + ")
            add = True
        if key.char == "-":
            print("当前为 -")
            add = False
        if add == True:
            if key.char == 'p':
                kp = round(kp + 0.001,4)
                print("P + 0.01, 当前 P ：",kp)

                pidx = PID(P=kp, I=ki, D=kd)
                pidy = PID(P=kp, I=ki, D=kd)
            elif key.char == "i":
                ki = round(ki + 0.001,4)
                print("i + 0.01, 当前 i ：", ki)
                pidx = PID(P=kp, I=ki, D=kd)
                pidy = PID(P=kp, I=ki, D=kd)
            elif key.char == 'k':
                kd = round(kd + 0.001,4)
                print("d + 0.01, 当前 d ：", kd)
                pidx = PID(P=kp, I=ki, D=kd)
                pidy = PID(P=kp, I=ki, D=kd)
        if add == False:
            if key.char == 'p':
                kp = round(kp - 0.001,4)
                print("P - 0.01, 当前 P ：",kp)
                pidx = PID(P=kp, I=ki, D=kd)
                pidy = PID(P=kp, I=ki, D=kd)
            elif key.char == "i":
                ki = round(ki - 0.001,4)
                print("i - 0.01, 当前 i ：", ki)
                pidx = PID(P=kp, I=ki, D=kd)
                pidy = PID(P=kp, I=ki, D=kd)
            elif key.char == 'k':
                kd = round(kd - 0.001,4)
                print("d - 0.01, 当前 d ：", kd)
                pidx = PID(P=kp, I=ki, D=kd)
                pidy = PID(P=kp, I=ki, D=kd)
    except:
        pass

def on_press():
    with pynput.keyboard.Listener(on_press=Key_press) as listener:
        listener.join()




@smart_inference_mode()
def run():


    # re_x, re_y = 640, 640  # 显示size
    # ------------------------------
    # PID係數可調整
    # PID(P, I, D)
    # P: 加快系統反映。輸出值較快，但越大越不穩定
    # I: 積分。用於穩定誤差
    # D: 微分。提高系統的動態性能
    # 以下為個人使用參數可供參考
    # pidx = PID(P=p, I=i, D=d)   #P=0.5, I=0.09, D=0.1  #P=0.81, I=0.22, D=0.19  #P=0.2,I=0.03,D=0.28 #P=0.6,I=0.03, D=0.1
    # pidy = PID(P=p, I=i, D=d) #P=0.6, I=0.1, D=0.4
    # ----------------------------------------------

    ## 加载模型
    weights = r'E:\Pycharm\Python_Projects\yolov5\aim-csgo\model\best_csgo.engine'
    # weights=r'E:\Pycharm\Python_Projects\yolov5\aim-csgo\model\csgo_28600p_20ep_5n_5.0_4lab.wts'
    imgsz = 640
    # device = 'cuda' if torch.cuda.is_available() else 'cpu'
    # model = load_model(weights=weights)
    device = torch.device('cuda:0')
    print("device ", device)
    model = DetectMultiBackend(weights, device=device, dnn=False, data=False, fp16=True)
    # -----------------
    stride, names, pt = model.stride, model.names, model.pt

    global lock_mode
    global pidy, pidy
    while True:

        if lock_mode == False:
            time.sleep(0.1)
            continue
        t0 = time.time()

        img0 = grab_screen_mss(monitor=(x1, y1, x2, y2))  # 截图  region范围  截图用时 0.02s 以内
        # img0 = cv2.resize(img0,(re_x, re_y))
        im = letterbox(img0, imgsz, stride=stride)[0]
        im = im.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
        im = np.ascontiguousarray(im)  # contiguous
        im = torch.from_numpy(im).to(model.device)
        im = im.half() if model.fp16 else im.float()  # uint8 to fp16/32
        im /= 255  # 0 - 255 to 0.0 - 1.0
        if len(im.shape) == 3:
            im = im[None]  # expand for batch dim

        t1 = time.time()
        pred = model(im)
        pred = non_max_suppression(pred, conf_thres=conf_thres, iou_thres=iou_thres, max_det=300)
        # print("推理用时", time.time() - t1)
        print("当前 PID值 P =", kp, "I =", ki, "D =", kd)
        for i, det in enumerate(pred):
            distance_list = []
            target_list = []
            # gn = torch.tensor(img0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            if len(det):
                det[:, :4] = scale_boxes(im.shape[2:], det[:, :4], img0.shape).round()

                for *xyxy, conf, cls in reversed(det):
                    # bbox:(tag, x_center, y_center, x_width, y_width)
                    """
                    0 ct_head 1 ct_body 2 t_heda 3 t_body
                    """
                    #xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                    xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4))).view(-1).tolist()  # normalized xywh
                    xywh = (int(cls), *xywh)  # label format  #xywh (tensor(1., device='cuda:0'), 335.0, 149.0, 26.0, 40.0)
                    x = xywh[1] - k
                    y = xywh[2] - k
                    distance = math.sqrt(x ** 2 + y ** 2)
                    distance_list.append(distance)
                    target_list.append(xywh)    #将每个目标添加进target_list  获得所有目标list
                target_info = target_list[distance_list.index(min(distance_list))]  #获取最近的目标参数
                #  #target_info: (1, 178.5, 354.5, 49.0, 137.0)
                # print("target_info:",target_info)#target_info:(tensor(0., device='cuda:0'), 369.0, 322.0, 8.0, 8.0)
                # tag, x_center, y_center, width, height = target_info  # 计算中心位置
                tag = target_info[0]
                # print("tag:" , tag)
                if tag == 0 or tag == 2:
                    #PID移动-------------start
                    x = int(pidx.SetStepSignal((target_info[1] - k) * move_P))
                    y = int(pidy.SetStepSignal((target_info[2] - k) * move_P))  #int((target_info[2] - k) * move_P)
                    mouse_xy(x, y)
                    #PID移动-------------end
                    # #正常移动--------------start
                    # mouse_xy(int(((target_info[1] - k) * move_P)), int((target_info[2] - k) * move_P))
                    # time.sleep(0.001)
                    # #正常移动----------end
                    print("移动数据x:",int((target_info[1] - k) * move_P),"y:",int((target_info[2] - k) * move_P))
                elif tag == 1 or tag == 3:
                    #PID移动-------------start
                    x = int(pidx.SetStepSignal((target_info[1] - k) * move_P))
                    y = int(pidy.SetStepSignal((target_info[2] - 4/10 * target_info[4] - k) * move_P))  #int((target_info[2] - 4/10 * target_info[4] - k) * move_P)
                    mouse_xy(x, y)
                    # PID移动-------------end
                    # # 正常移动--------------start
                    # mouse_xy(int(((target_info[1] - k) * move_P)), int((target_info[2] - 4/10 * target_info[4] - k) * move_P))
                    # time.sleep(0.001)
                    print("移动数据x:", int((target_info[2] - 4/10 * target_info[4] - k) * move_P), "y:", int((target_info[2] - k) * move_P))
                    # # 正常移动----------end
                # time.sleep(1)
                # time.sleep(0.001)
                print("当前 PID值 P =", kp, "I =", ki, "D =",kd , "pidx.LastError:" ,pidx.LastError ,"pidx.Error:",pidx.Error)
                print("程序用时 ", time.time() - t0, "FPS:",int(1/(time.time() - t0)), "\n")

                    # print("height" , target_info[4],"\n")w
#
# with pynput.mouse.Events() as events:
#     while True:
#         t0 = time.time()
#         it = next(events)  #程序运行未用时  暂停用时 15ms
#         while it is not None and not isinstance(it, pynput.mouse.Events.Click): #鼠标不是None 和 不是被点击 就迭代
#             it = next(events)
#         if it is not None and it.button == it.button.middle and it.pressed: #and it.pressed  是被按下
#             lock_mode = not lock_mode
#             print('lock mode', 'on' if lock_mode else 'off')
#         if lock_mode == False:
#             continue
#         img0 = grab_screen_mss(monitor=(x1, y1, x2, y2))   #截图  region范围  截图用时 0.02s 以内
#         # img0 = cv2.resize(img0,(re_x, re_y))
#         im = letterbox(img0, imgsz, stride=stride)[0]
#         im = im.transpose((2, 0, 1))[::-1]  # HWC to CHW, BGR to RGB
#         im = np.ascontiguousarray(im)  # contiguous
#         im = torch.from_numpy(im).to(model.device)
#         im = im.half() if model.fp16 else im.float()  # uint8 to fp16/32
#         im /= 255  # 0 - 255 to 0.0 - 1.0
#         if len(im.shape) == 3:
#             im = im[None]  # expand for batch dim
#
#         pidx(0)
#         # pidy(0)
#
#         t1 = time.time()
#         pred = model(im)
#         pred = non_max_suppression(pred, conf_thres=conf_thres, iou_thres=iou_thres, max_det=300)
#         print("推理用时",time.time()-t1)
#
#         aims = []
#
#         for i,det in enumerate(pred):
#             s = ''
#             s += '%gx%g ' % im.shape[2:]
#             gn = torch.tensor(img0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
#             if len(det):
#                 det[:, :4] = scale_boxes(im.shape[2:], det[:, :4], img0.shape).round()
#                 # Print results
#                 # for c in det[:, 5].unique():
#                 #     n = (det[:, 5] == c).sum()  # detections per class
#                 #     s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # add to string
#
#                 for *xyxy, conf, cls in reversed(det):
#                     #bbox:(tag, x_center, y_center, x_width, y_width)
#                     """
#                     0 ct_head 1 ct_body 2 t_heda 3 t_body
#                     """
#                     xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
#                     line = (cls, *xywh)  # label format
#                     aim = ('%g ' * len(line)).rstrip() % line #+ '\n'
#                     aim = aim.split(' ')
#                     # print(aim) #输出检测到的物体坐标类型 str
#                     aims.append(aim)
#             if len(aims):
#                 if lock_mode:
#                     lock(aims, x_c, y_c, pidx) #pid
#                     # lock(aims, x_c, y_c)
#                     print("程序用时 ", time.time() - t0, "\n")
#                     break

                    # time.sleep(0.01)
        #         for i, det in enumerate(aims):  # 可视化框
        #             _, x_center, y_center, width, hight = det
        #             x_center, width = re_x * float(x_center), re_x * float(width)
        #             y_center, hight = re_y * float(y_center), re_y * float(hight)
        #             top_left = (int(x_center - width / 2), int(y_center - hight / 2))
        #             bottom_right = (int(x_center + width / 2), int(y_center + hight / 2))
        #             color = (0, 255, 0) # RGB
        #             cv2.rectangle(img0, top_left, bottom_right, color, thickness=3)
        #
        #
        #
        # #可视化框
        # cv2.namedWindow("csgo-detect",cv2.WINDOW_NORMAL)
        # cv2.resizeWindow("csgo-detect", re_x, re_y)
        # cv2.imshow("csgo-detect",img0)
        # hwnd = win32gui.FindWindow(None , 'csgo-detect')
        # CVRECT = cv2.getWindowImageRect('csgo-detect')
        # win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 0, 0, 0, 0, win32con.SWP_NOMOVE | win32con.SWP_NOSIZE)
        # if cv2.waitKey(1) & 0xFF == ord('q'):
        #     cv2.destroyAllWindows()
        #     break


if __name__ == "__main__":
    mouse_listener = Thread(target=open_listener).start()
    # add_PID = Thread(target=on_press).start()
    run()
    # move_Listener = Thread(target=move_Listener).start()

